def test():
    print('test')