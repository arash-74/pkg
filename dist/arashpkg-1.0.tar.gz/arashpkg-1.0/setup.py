from setuptools import setup
setup(
    name='arashpkg',
    version='1.0',
    author='arash',
    packages=['pkgfolder'],
)